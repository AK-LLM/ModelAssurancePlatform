from __future__ import annotations

import json
from typing import Dict


def markdown_report(campaign: Dict[str, object]) -> str:
    lines = [
        f"# ModelAssurancePlatform v1.7 — {campaign['campaign_id']}",
        "",
        f"Mode: **{campaign['mode']}**",
        f"Decision: **{campaign['governance']['decision']}**",
        f"Rationale: {campaign['governance']['rationale']}",
        "",
        "## Summary",
    ]
    for k, v in campaign['summary'].items():
        lines.append(f"- **{k.replace('_', ' ').title()}**: {v}")
    lines.append("")
    lines.append("## Findings")
    for finding in campaign['findings']:
        lines.append(f"### {finding['finding_id']} — {finding['title']}")
        lines.append(f"- Severity: **{finding['severity']}**")
        lines.append(f"- Domain: **{finding['domain']}**")
        lines.append(f"- Summary: {finding['summary']}")
        lines.append(f"- Causes: {', '.join(c['cause'] for c in finding['cause_hypotheses'])}")
        lines.append("- Remediation:")
        for fix in finding['remediation_plan']:
            lines.append(f"  - {fix['fix_id']}: {fix['action']}")
        lines.append("- Verification:")
        for step in finding['verification_plan']:
            lines.append(f"  - {step['fix_id']}: {step['closure_criteria']}")
        lines.append("")
    lines.append("## Safety Case")
    lines.append(f"- Claim: {campaign['governance']['safety_case']['claim']}")
    for item in campaign['governance']['safety_case']['evidence']:
        lines.append(f"- Evidence: {item}")
    return "\n".join(lines)


def json_report(campaign: Dict[str, object]) -> str:
    return json.dumps(campaign, indent=2, ensure_ascii=False)
