# Expansion recommendations to push toward a true 9/10 suite

## Highest-value additions
1. Gold evaluation corpora with expected outcomes for each probe family.
2. Provider-specific adapters with request schemas, retries, telemetry, and response normalization.
3. Multi-turn agent workflow simulator for tool misuse, memory abuse, and chained exfiltration.
4. Retrieval-grounded eval harness with chunk poisoning, citation integrity, and answer-groundedness scoring.
5. Calibration datasets for regulated domains to validate false negatives on privacy, PHI, policy bypass, and emergency escalation.
6. Signed evidence ledger and tamper-evident manifests for output packs.
7. Statistical drift baselines built from prior campaign histories rather than static thresholds.
8. Domain-specific governance packs for healthcare, finance, legal, government, education, and consumer support.

## What the current hardened build improves
- Operability
- Internal consistency
- Release governance
- Validation depth
- Output richness

## What still needs substantive content work
- External benchmark grounding
- Broader scenario assets
- More realistic model integration
- Multi-turn/adaptive adversary testing
- Historical baseline data at scale
